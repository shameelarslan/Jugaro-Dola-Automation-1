# browser package initialization
