"""Core package"""
