# ai package initialization
