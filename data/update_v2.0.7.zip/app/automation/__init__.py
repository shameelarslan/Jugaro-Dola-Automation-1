# automation package initialization
